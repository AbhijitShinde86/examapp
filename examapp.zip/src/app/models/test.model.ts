export interface Test {
    id: string;
    questions: any;
    attemptedQuestion: number
    correctAnswered: number
    result: string
}