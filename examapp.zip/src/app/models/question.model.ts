export interface Question {
    id: number;
    question: string;
    option1: Boolean,
    option2:Boolean,
    correctanswer: Boolean
}